#include <iostream>

using namespace std;

int numerouno;
int numeroduo;

int main() {
    // The initializer
    cout << "Enter 2 numbers below which you want to add together\n";
    // The first number
    cout << "Number 1: ";
    cin >> numerouno;
    // The second number
    cout << "Number 2: ";
    cin >> numeroduo;
    // Adds the numbers and sends them to the console
    cout << numerouno + numeroduo;
}