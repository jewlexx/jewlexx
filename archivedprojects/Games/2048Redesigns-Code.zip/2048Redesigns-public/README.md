Redesigns of [2048](jamesafk.github.io/2048reworks/) game
========================================================================

### Massive credit to [*Simon Owen*](https://github.com/s10wen) and [*Alex Petrosh*](https://github.com/petrosh) at [*0x0800*](https://github.com/0x0800) for making most of these

### Even more massive credit to [*Gabriele Cirulli*](https://github.com/gabrielecirulli) for making the original

**NOTE:** *For dev run npm install inside the folder to download required dependencies.*
