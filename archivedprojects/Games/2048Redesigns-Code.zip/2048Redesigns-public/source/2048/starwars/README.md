Star Wars version of [2048](http://gabrielecirulli.github.io/2048/) game
========================================================================

Play here: http://git.io/starwars

[![2048 STARWARS](https://pbs.twimg.com/media/Bj6KnEUCQAAAMpc.png:large)](http://git.io/starwars)