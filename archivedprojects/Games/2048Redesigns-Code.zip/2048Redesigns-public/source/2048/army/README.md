Army version of [2048](http://gabrielecirulli.github.io/2048/) game
===================================================================

Play here: http://git.io/army

[![2048 ARMY](https://pbs.twimg.com/media/Bj6LMCtCAAAogbd.png:large)](http://git.io/army)