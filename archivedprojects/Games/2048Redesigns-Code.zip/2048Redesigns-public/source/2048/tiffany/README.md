Tiffany version of [2048](http://gabrielecirulli.github.io/2048/) game
========================================================================

Play here: http://git.io/tiffany

[![2048 TIFFANY](http://oi59.tinypic.com/10wk1uf.jpg)](http://git.io/tiffany)