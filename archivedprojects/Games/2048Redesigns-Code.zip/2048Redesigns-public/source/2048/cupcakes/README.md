Cupcakes version of [2048](http://gabrielecirulli.github.io/2048/) game
========================================================================

Play here: http://git.io/cupcakes

[![2048 CUPCAKES](http://oi62.tinypic.com/9u7rkk.jpg)](http://git.io/cupcakes)